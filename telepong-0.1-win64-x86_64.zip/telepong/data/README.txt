Place here all the data files that you may load during the game execution.
See https://castle-engine.io/data .
